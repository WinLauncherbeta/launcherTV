package com.meulauncher.tv

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File

/**
 * Navegador embutido no site MoeWalls. Qualquer download (mp4/webm/imagem) é interceptado,
 * salvo em "wallpapers" e, ao terminar, o app pergunta se quer usar como papel de parede.
 */
class WallpaperBrowserActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var prefs: Prefs
    private val pending = HashMap<Long, File>()

    private val doneReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val id = i?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: return
            val file = pending.remove(id) ?: return
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            val cur = dm.query(DownloadManager.Query().setFilterById(id))
            var ok = false
            cur.use { if (it.moveToFirst()) ok = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL }
            if (ok && file.exists()) askUse(file)
            else Toast.makeText(this@WallpaperBrowserActivity, "Falha no download", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.mediaPlaybackRequiresUserGesture = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        CookieManager.getInstance().setAcceptCookie(true)
        web.isFocusable = true
        web.isFocusableInTouchMode = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (isFileUrl(url)) {
                    startDownload(url, null, null)
                    return true
                }
                return false
            }
        }
        web.setDownloadListener { url, ua, disp, mime, _ -> startDownload(url, disp, mime, ua) }

        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        val f = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(doneReceiver, f, 2) // RECEIVER_EXPORTED
        else registerReceiver(doneReceiver, f)

        web.loadUrl("https://moewalls.com/")
        web.requestFocus()
        Toast.makeText(this, "Abra um wallpaper e toque em Download. Voltar = página anterior.", Toast.LENGTH_LONG).show()
    }

    private fun isFileUrl(url: String): Boolean {
        val u = url.substringBefore('?').lowercase()
        return u.endsWith(".mp4") || u.endsWith(".webm") || u.endsWith(".mkv") ||
            u.endsWith(".jpg") || u.endsWith(".jpeg") || u.endsWith(".png") || u.endsWith(".webp")
    }

    private fun startDownload(url: String, disp: String?, mime: String?, ua: String? = null) {
        try {
            val dir = wallpaperDir(this)
            var name = URLUtil.guessFileName(url, disp, mime)
            name = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            var file = File(dir, name)
            var n = 1
            while (file.exists()) {
                file = File(dir, name.substringBeforeLast('.') + "_" + n + "." + name.substringAfterLast('.', "mp4"))
                n++
            }
            val req = DownloadManager.Request(Uri.parse(url))
            req.setTitle(file.name)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationUri(Uri.fromFile(file))
            req.addRequestHeader("Referer", "https://moewalls.com/")
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            req.addRequestHeader("User-Agent", ua ?: web.settings.userAgentString)
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            pending[dm.enqueue(req)] = file
            Toast.makeText(this, "Baixando ${file.name}…", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível baixar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun askUse(file: File) {
        if (isFinishing) return
        AlertDialog.Builder(this)
            .setTitle("Download concluído")
            .setMessage("${file.name}\n\nUsar como papel de parede agora?")
            .setPositiveButton("Usar agora") { _, _ ->
                prefs.customWallpaper = file.absolutePath
                prefs.wallpaper = 3
                Toast.makeText(this, "Papel de parede aplicado", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Depois", null)
            .show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && web.canGoBack()) {
            web.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        try { unregisterReceiver(doneReceiver) } catch (_: Exception) {}
        web.destroy()
        super.onDestroy()
    }

    companion object {
        fun wallpaperDir(ctx: Context): File {
            val d = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "wallpapers")
            if (!d.exists()) d.mkdirs()
            return d
        }
    }
}
