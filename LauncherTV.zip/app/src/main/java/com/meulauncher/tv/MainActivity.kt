package com.meulauncher.tv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var video: VideoView
    private lateinit var tvDay: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvWeather: TextView
    private lateinit var tvTime: TextView
    private lateinit var monitor: TextView
    private lateinit var dock: LinearLayout
    private lateinit var scroller: HorizontalScrollView
    private lateinit var anurati: Typeface
    private lateinit var root: FrameLayout

    // Janela "Todos os apps"
    private lateinit var panelLayer: FrameLayout
    private lateinit var panelCard: LinearLayout
    private lateinit var panelSearch: EditText
    private lateinit var panelWeather: TextView
    private lateinit var panelRv: RecyclerView
    private val panelAdapter = PanelAdapter()
    private var allApps: List<AppItem> = emptyList()
    private var panelFavs = mutableListOf<String>()

    private val handler = Handler(Looper.getMainLooper())
    private val cpu = CpuTracker()
    private val loc = Locale("pt", "BR")

    private val clockTick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 1000L)
        }
    }

    private val monitorTick = object : Runnable {
        override fun run() {
            updateMonitor()
            handler.postDelayed(this, if (prefs.economy) 4000L else 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        root = FrameLayout(this)
        root.clipChildren = false

        // Fundo animado (o fundo estático fica no próprio window background)
        video = VideoView(this)
        video.isFocusable = false
        video.isFocusableInTouchMode = false
        root.addView(
            video,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        // Relógio (canto superior esquerdo)
        anurati = Typeface.createFromAsset(assets, "fonts/anurati.otf")
        val shadow = Color.parseColor("#99000000")

        tvDay = TextView(this)
        tvDay.typeface = anurati
        tvDay.textSize = 40f
        tvDay.letterSpacing = 0.2f
        tvDay.setTextColor(Color.WHITE)
        tvDay.setShadowLayer(10f, 0f, 2f, shadow)

        tvDate = TextView(this)
        tvDate.typeface = anurati
        tvDate.textSize = 16f
        tvDate.letterSpacing = 0.15f
        tvDate.setTextColor(Color.parseColor("#FFEDE5")) 
        tvDate.setShadowLayer(8f, 0f, 2f, shadow)

        tvWeather = TextView(this)
        tvWeather.textSize = 16f
        tvWeather.setTextColor(Color.WHITE)
        tvWeather.setShadowLayer(8f, 0f, 2f, shadow)

        tvTime = TextView(this)
        tvTime.textSize = 16f
        tvTime.letterSpacing = 0.1f
        tvTime.setTextColor(Color.WHITE)
        tvTime.setShadowLayer(8f, 0f, 2f, shadow)

        val timeRow = LinearLayout(this)
        timeRow.orientation = LinearLayout.HORIZONTAL
        timeRow.gravity = Gravity.CENTER_VERTICAL
        timeRow.addView(tvWeather)
        val gap = View(this)
        timeRow.addView(gap, LinearLayout.LayoutParams(dp(14), 1))
        timeRow.addView(tvTime)

        val clockBox = LinearLayout(this)
        clockBox.orientation = LinearLayout.VERTICAL
        clockBox.gravity = Gravity.CENTER_HORIZONTAL
        clockBox.addView(tvDay)
        val lpDate = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpDate.topMargin = dp(6)
        clockBox.addView(tvDate, lpDate)
        val lpRow = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpRow.topMargin = dp(6)
        clockBox.addView(timeRow, lpRow)

        val lpClock = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.START
        )
        lpClock.setMargins(dp(32), dp(28), 0, 0)
        root.addView(clockBox, lpClock)

        // Monitor de RAM / CPU
        monitor = TextView(this)
        monitor.textSize = 13f
        monitor.setTextColor(Color.WHITE)
        monitor.setPadding(dp(14), dp(8), dp(14), dp(8))
        val mbg = GradientDrawable()
        mbg.cornerRadius = dpf(12)
        mbg.setColor(Color.parseColor("#88000000"))
        monitor.background = mbg
        root.addView(
            monitor,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            )
        )

        // Dock
        dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        dock.clipChildren = false
        dock.setPadding(dp(8), dp(6), dp(8), dp(6))

        scroller = HorizontalScrollView(this)
        scroller.isHorizontalScrollBarEnabled = false
        scroller.clipToPadding = false
        scroller.clipChildren = false
        scroller.isFocusable = false
        scroller.setPadding(dp(14), dp(16), dp(14), dp(16))
        scroller.addView(dock)
        root.addView(
            scroller,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
        )

        buildPanel()
        setContentView(root)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        hidePanel(false)
    }

    override fun onStart() {
        super.onStart()
        applyBackground()
    }

    override fun onResume() {
        super.onResume()
        hidePanel(false)
        positionMonitor()
        applyClockFont()
        applyDockStyle()
        buildDock()
        updateClock()
        showWeather()
        refreshWeather()
        handler.removeCallbacks(clockTick)
        handler.removeCallbacks(monitorTick)
        handler.postDelayed(clockTick, 1000L)
        handler.post(monitorTick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(clockTick)
        handler.removeCallbacks(monitorTick)
    }

    override fun onStop() {
        super.onStop()
        // libera o decodificador de vídeo quando outro app está aberto
        video.stopPlayback()
    }

    private fun applyBackground() {
        val mode = if (prefs.economy) 2 else prefs.wallpaper
        if (mode == 2) {
            video.stopPlayback()
            video.visibility = View.GONE
            return
        }
        video.visibility = View.VISIBLE
        val res = if (mode == 0) R.raw.wallpaper_1 else R.raw.wallpaper_2
        video.setOnPreparedListener { mp ->
            mp.isLooping = true
            mp.setVolume(0f, 0f)
        }
        video.setOnErrorListener { _, _, _ ->
            video.visibility = View.GONE
            true
        }
        video.setVideoURI(Uri.parse("android.resource://$packageName/$res"))
        video.start()
    }

    private fun positionMonitor() {
        val lp = monitor.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (prefs.monitorBottom) (Gravity.BOTTOM or Gravity.END) else (Gravity.TOP or Gravity.END)
        lp.setMargins(0, dp(28), dp(32), dp(28))
        monitor.layoutParams = lp
        monitor.visibility = if (prefs.monitorOn) View.VISIBLE else View.GONE
    }

    private fun updateClock() {
        val now = Date()
        tvDay.text = SimpleDateFormat("EEEE", loc).format(now).substringBefore('-').trim().uppercase(loc)
        tvDate.text = SimpleDateFormat("dd MMMM, yyyy.", loc).format(now).uppercase(loc)
        val pattern = if (prefs.clock24) "HH:mm" else "hh:mm a"
        tvTime.text = "- " + SimpleDateFormat(pattern, loc).format(now) + " -"
    }

    private fun showWeather() {
        tvWeather.text = if (prefs.weatherCity == prefs.city) prefs.weatherText else ""
    }

    private fun refreshWeather() {
        val now = System.currentTimeMillis()
        val fresh = now - prefs.weatherTime < 30L * 60L * 1000L && prefs.weatherCity == prefs.city
        if (fresh) return
        val city = prefs.city
        Thread {
            val r = Weather.fetch(city)
            if (r != null) {
                prefs.weatherText = Weather.emoji(r.code) + " " + r.temp + "°"
                prefs.weatherCity = city
                prefs.weatherTime = System.currentTimeMillis()
                runOnUiThread { showWeather() }
            }
        }.start()
    }

    private fun updateMonitor() {
        if (!prefs.monitorOn) {
            monitor.visibility = View.GONE
            return
        }
        monitor.visibility = View.VISIBLE
        val m = SysInfo.memory(this)
        val freq = SysInfo.cpuFreqMhz()
        val cpuLine = "CPU ${SysInfo.cores} núcleos" +
            (if (freq != null) " · $freq MHz" else "") +
            " · launcher ${cpu.appPercent()}%"
        monitor.text = "RAM ${m.usedMb}/${m.totalMb} MB (${m.percent}%)\n$cpuLine"
        monitor.setTextColor(
            when {
                m.percent >= 85 -> Color.parseColor("#FF6B6B")
                m.percent >= 70 -> Color.parseColor("#FFD166")
                else -> Color.parseColor("#7CF29A")
            }
        )
    }

    // ---------- Dock ----------

    /** Fonte do relógio: Anurati (original) ou a fonte padrão do sistema. */
    private fun applyClockFont() {
        if (prefs.clockFont == 1) {
            tvDay.typeface = Typeface.DEFAULT_BOLD
            tvDate.typeface = Typeface.DEFAULT_BOLD
            tvDay.letterSpacing = 0.08f
            tvDate.letterSpacing = 0.08f
        } else {
            tvDay.typeface = anurati
            tvDate.typeface = anurati
            tvDay.letterSpacing = 0.2f
            tvDate.letterSpacing = 0.15f
        }
    }

    /** Aplica posição (esquerda/meio/direita) e fundo (opacidade) do dock. */
    private fun applyDockStyle() {
        val h = when (prefs.dockAlign) {
            0 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.CENTER_HORIZONTAL
        }
        val lp = scroller.layoutParams as FrameLayout.LayoutParams
        lp.gravity = Gravity.BOTTOM or h
        lp.setMargins(dp(24), 0, dp(24), 0)
        scroller.layoutParams = lp

        val a = prefs.dockBg * 255 / 100
        if (a <= 0) {
            dock.background = null
        } else {
            val dbg = GradientDrawable()
            dbg.cornerRadius = dpf(22)
            dbg.setColor(Color.argb(a, 0, 0, 0))
            dock.background = dbg
        }
    }

    private fun buildDock(focusFirst: Boolean = true) {
        dock.removeAllViews()
        val sizeDp = intArrayOf(40, 56, 76)[prefs.iconSize.coerceIn(0, 2)]

        val iconApps = resources.getDrawable(R.drawable.ic_apps, theme)
        dock.addView(
            tile(iconApps, sizeDp, Color.parseColor("#1E6BFF"), 10, {
                if (panelLayer.visibility == View.VISIBLE) hidePanel(true) else showPanel()
            }, null)
        )

        val favs = prefs.favorites()
        for (pkg in favs) {
            val app = Apps.load(this, pkg) ?: continue
            dock.addView(
                tile(app.icon, sizeDp, null, 0, { Apps.launch(this, app) }, {
                    val list = prefs.favorites()
                    list.remove(pkg)
                    prefs.setFavorites(list)
                    buildDock()
                })
            )
        }

        val iconGear = resources.getDrawable(R.drawable.ic_gear, theme)
        dock.addView(
            tile(iconGear, sizeDp, null, 8, {
                startActivity(Intent(this, SettingsActivity::class.java))
            }, null)
        )

        if (focusFirst) dock.getChildAt(0)?.requestFocus()
    }

    private fun tile(
        icon: Drawable,
        sizeDp: Int,
        bgColor: Int?,
        padDp: Int,
        onClick: () -> Unit,
        onLong: (() -> Unit)?
    ): View {
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(4), dp(4), dp(4), dp(4))
        wrap.background = focusBg(18)
        wrap.isFocusable = true
        wrap.isClickable = true
        wrap.clipChildren = false

        val iv = ImageView(this)
        iv.setImageDrawable(icon)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        if (bgColor != null) {
            val bg = GradientDrawable()
            bg.cornerRadius = dpf(14)
            bg.setColor(bgColor)
            iv.background = bg
        }
        if (padDp > 0) iv.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
        val radius = dpf(14)
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        iv.clipToOutline = true
        wrap.addView(iv, FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp)))

        wrap.setOnClickListener { onClick() }
        if (onLong != null) {
            wrap.setOnLongClickListener {
                onLong()
                true
            }
        }
        wrap.scaleOnFocus(1.15f)

        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(4), 0, dp(4), 0)
        wrap.layoutParams = lp
        return wrap
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // launcher não fecha com o botão voltar; só fecha a janela de apps
        if (panelLayer.visibility == View.VISIBLE) hidePanel(true)
    }

    // ---------- Janela "Todos os apps" (sobe em cima do dock) ----------

    private fun buildPanel() {
        panelLayer = FrameLayout(this)
        panelLayer.visibility = View.GONE
        panelLayer.setBackgroundColor(Color.parseColor("#55000000"))
        panelLayer.isClickable = true
        panelLayer.setOnClickListener { hidePanel(true) }

        panelCard = LinearLayout(this)
        panelCard.orientation = LinearLayout.VERTICAL
        panelCard.setPadding(dp(14), dp(14), dp(14), dp(10))
        val cardBg = GradientDrawable()
        cardBg.cornerRadius = dpf(20)
        cardBg.setColor(Color.parseColor("#F01C1E22"))
        panelCard.background = cardBg
        panelCard.isClickable = true

        // Barra de pesquisa
        val searchRow = LinearLayout(this)
        searchRow.orientation = LinearLayout.HORIZONTAL
        searchRow.gravity = Gravity.CENTER_VERTICAL
        searchRow.setPadding(dp(14), dp(2), dp(14), dp(2))
        val sbg = GradientDrawable()
        sbg.cornerRadius = dpf(24)
        sbg.setColor(Color.parseColor("#3DFFFFFF"))
        searchRow.background = sbg

        val magnifier = TextView(this)
        magnifier.text = "\uD83D\uDD0D"
        magnifier.textSize = 14f
        searchRow.addView(magnifier)

        panelSearch = EditText(this)
        panelSearch.hint = "Digite aqui para pesquisar"
        panelSearch.setHintTextColor(Color.parseColor("#AAFFFFFF"))
        panelSearch.setTextColor(Color.WHITE)
        panelSearch.textSize = 14f
        panelSearch.setSingleLine()
        panelSearch.background = null
        panelSearch.setPadding(dp(10), dp(8), dp(10), dp(8))
        panelSearch.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        panelSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                panelAdapter.filter(s?.toString() ?: "")
            }
        })
        searchRow.addView(panelSearch, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        panelWeather = TextView(this)
        panelWeather.textSize = 14f
        panelWeather.setTextColor(Color.WHITE)
        searchRow.addView(panelWeather)

        panelCard.addView(searchRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val title = TextView(this)
        title.text = "Todos os aplicativos"
        title.textSize = 14f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        val lpTitle = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpTitle.setMargins(dp(6), dp(12), 0, dp(4))
        panelCard.addView(title, lpTitle)

        panelRv = RecyclerView(this)
        panelRv.layoutManager = GridLayoutManager(this, 5)
        panelRv.adapter = panelAdapter
        panelRv.clipToPadding = false
        panelRv.itemAnimator = null
        panelCard.addView(panelRv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Rodapé: nome + engrenagem
        val line = View(this)
        line.setBackgroundColor(Color.parseColor("#33FFFFFF"))
        val lpLine = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        lpLine.topMargin = dp(6)
        panelCard.addView(line, lpLine)

        val footer = LinearLayout(this)
        footer.orientation = LinearLayout.HORIZONTAL
        footer.gravity = Gravity.CENTER_VERTICAL
        footer.setPadding(dp(6), dp(6), dp(2), 0)

        val name = TextView(this)
        name.text = "Meu Launcher"
        name.textSize = 13f
        name.setTextColor(Color.parseColor("#CCFFFFFF"))
        footer.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val gear = ImageView(this)
        gear.setImageDrawable(resources.getDrawable(R.drawable.ic_gear, theme))
        gear.setPadding(dp(6), dp(6), dp(6), dp(6))
        gear.background = focusBg(10)
        gear.isFocusable = true
        gear.isClickable = true
        gear.setOnClickListener {
            hidePanel(false)
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        footer.addView(gear, LinearLayout.LayoutParams(dp(36), dp(36)))
        panelCard.addView(footer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val lpCard = FrameLayout.LayoutParams(dp(460), dp(380), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        panelLayer.addView(panelCard, lpCard)
        root.addView(panelLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun showPanel() {
        // alinha a janela com o dock e sobe logo acima dele
        val dockH = if (scroller.height > 0) scroller.height else dp(120)
        val h = when (prefs.dockAlign) {
            0 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.CENTER_HORIZONTAL
        }
        val lp = panelCard.layoutParams as FrameLayout.LayoutParams
        lp.gravity = Gravity.BOTTOM or h
        lp.setMargins(dp(24), 0, dp(24), dockH + dp(4))
        val maxH = root.height - dockH - dp(40)
        lp.height = if (maxH > 0) minOf(dp(380), maxH) else dp(380)
        panelCard.layoutParams = lp

        panelFavs = prefs.favorites()
        panelSearch.setText("")
        panelWeather.text = if (prefs.weatherCity == prefs.city) prefs.weatherText else ""
        panelAdapter.setData(allApps)

        panelLayer.visibility = View.VISIBLE
        scroller.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        panelRv.post { panelRv.getChildAt(0)?.requestFocus() }

        Thread {
            val apps = Apps.listAll(this)
            runOnUiThread {
                allApps = apps
                if (panelLayer.visibility == View.VISIBLE) {
                    val first = allApps.isEmpty().not() && panelAdapter.itemCount == 0
                    panelAdapter.setData(apps)
                    panelAdapter.filter(panelSearch.text.toString())
                    if (first) panelRv.post { panelRv.getChildAt(0)?.requestFocus() }
                }
            }
        }.start()
    }

    private fun hidePanel(focusDock: Boolean) {
        if (!::panelLayer.isInitialized || panelLayer.visibility != View.VISIBLE) return
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(panelSearch.windowToken, 0)
        panelLayer.visibility = View.GONE
        scroller.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        if (focusDock) dock.getChildAt(0)?.requestFocus()
    }

    private inner class PanelHolder(val view: LinearLayout, val icon: ImageView, val label: TextView) :
        RecyclerView.ViewHolder(view)

    private inner class PanelAdapter : RecyclerView.Adapter<PanelHolder>() {
        private var source: List<AppItem> = emptyList()
        private var shown: List<AppItem> = emptyList()

        fun setData(list: List<AppItem>) {
            source = list
            shown = list
            notifyDataSetChanged()
        }

        fun filter(q: String) {
            val t = q.trim().lowercase()
            shown = if (t.isEmpty()) source else source.filter { it.label.lowercase().contains(t) }
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PanelHolder {
            val item = LinearLayout(this@MainActivity)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(dp(4), dp(8), dp(4), dp(6))
            item.background = focusBg(12)
            item.isFocusable = true
            item.isClickable = true
            item.scaleOnFocus(1.06f)

            val icon = ImageView(this@MainActivity)
            icon.scaleType = ImageView.ScaleType.FIT_CENTER
            item.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))

            val label = TextView(this@MainActivity)
            label.textSize = 11f
            label.setTextColor(Color.WHITE)
            label.maxLines = 1
            label.ellipsize = TextUtils.TruncateAt.END
            label.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(4)
            item.addView(label, lp)

            item.layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            return PanelHolder(item, icon, label)
        }

        override fun getItemCount(): Int = shown.size

        override fun onBindViewHolder(h: PanelHolder, position: Int) {
            val app = shown[position]
            h.icon.setImageDrawable(app.icon)
            h.label.text = (if (panelFavs.contains(app.pkg)) "★ " else "") + app.label
            h.view.setOnClickListener {
                hidePanel(false)
                Apps.launch(this@MainActivity, app)
            }
            h.view.setOnLongClickListener {
                if (panelFavs.contains(app.pkg)) {
                    panelFavs.remove(app.pkg)
                    Toast.makeText(this@MainActivity, "${app.label} removido do dock", Toast.LENGTH_SHORT).show()
                } else {
                    panelFavs.add(app.pkg)
                    Toast.makeText(this@MainActivity, "${app.label} fixado no dock", Toast.LENGTH_SHORT).show()
                }
                prefs.setFavorites(panelFavs)
                notifyItemChanged(h.adapterPosition)
                buildDock(false)
                true
            }
        }
    }
}
