package com.meulauncher.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Configurações: menu lateral com categorias + painel de opções à direita.
 * Controle remoto: ↑ ↓ navega, → entra nas opções, ← / → ajusta valores, OK alterna, Voltar sai.
 */
class SettingsActivity : Activity() {

    private class Page(val name: String, val build: () -> Unit)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val accent = Color.parseColor("#4C8DFF")
    private val textDim = Color.parseColor("#B3FFFFFF")
    private val textFaint = Color.parseColor("#80FFFFFF")

    private lateinit var prefs: Prefs
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var pages: List<Page>
    private val sideItems = mutableListOf<TextView>()
    private var current = -1

    private var ramText: TextView? = null
    private var ramFill: View? = null
    private var ramRest: View? = null

    private val handler = Handler(Looper.getMainLooper())
    private val ramTick = object : Runnable {
        override fun run() {
            updateRam()
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        pages = listOf(
            Page("Aparência") { pageAppearance() },
            Page("Barra de tarefas") { pageDock() },
            Page("Relógio") { pageClock() },
            Page("Monitor") { pageMonitor() },
            Page("Memória") { pageMemory() },
            Page("Sistema") { pageSystem() }
        )

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#B3000000"))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.background = rounded(24, Color.parseColor("#F2101418"))
        val lpCard = FrameLayout.LayoutParams(MATCH, MATCH)
        lpCard.setMargins(dp(56), dp(28), dp(56), dp(28))
        root.addView(card, lpCard)

        // ---------- Menu lateral ----------
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.setPadding(dp(18), dp(26), dp(18), dp(18))
        val r = dpf(24)
        val sideBg = GradientDrawable()
        sideBg.setColor(Color.parseColor("#33000000"))
        sideBg.cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        side.background = sideBg

        val title = TextView(this)
        title.text = "Configurações"
        title.textSize = 20f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        title.setPadding(dp(8), 0, 0, dp(18))
        side.addView(title)

        pages.forEachIndexed { i, p ->
            val t = TextView(this)
            t.text = p.name
            t.textSize = 16f
            t.setTextColor(Color.WHITE)
            t.setPadding(dp(16), dp(12), dp(16), dp(12))
            t.background = sideItemBg()
            t.isFocusable = true
            t.isClickable = true
            t.onFocusChangeListener = View.OnFocusChangeListener { _, has -> if (has) showPage(i) }
            t.setOnClickListener {
                showPage(i)
                focusFirstRow()
            }
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.bottomMargin = dp(4)
            side.addView(t, lp)
            sideItems.add(t)
        }

        side.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        val hint = TextView(this)
        hint.text = "→ entra nas opções\n← → ajusta valores\nOK alterna · Voltar sai"
        hint.textSize = 12f
        hint.setTextColor(textFaint)
        hint.setPadding(dp(8), 0, 0, 0)
        side.addView(hint)

        card.addView(side, LinearLayout.LayoutParams(dp(250), MATCH))

        // ---------- Painel de opções ----------
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(28), dp(24), dp(28), dp(24))

        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        card.addView(scroll, LinearLayout.LayoutParams(0, MATCH, 1f))

        setContentView(root)
        showPage(0)
        sideItems[0].requestFocus()
    }

    override fun onResume() {
        super.onResume()
        handler.post(ramTick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ramTick)
    }

    // ---------- Navegação ----------

    private fun showPage(i: Int) {
        if (i == current) return
        current = i
        sideItems.forEachIndexed { k, v -> v.isSelected = (k == i) }
        ramText = null
        ramFill = null
        ramRest = null
        content.removeAllViews()
        scroll.scrollTo(0, 0)

        val t = TextView(this)
        t.text = pages[i].name
        t.textSize = 26f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(Color.WHITE)
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.bottomMargin = dp(18)
        content.addView(t, lp)

        pages[i].build()
    }

    private fun focusFirstRow() {
        for (k in 0 until content.childCount) {
            val v = content.getChildAt(k)
            if (v.isFocusable) {
                v.requestFocus()
                return
            }
        }
    }

    // ---------- Páginas ----------

    private fun pageAppearance() {
        segmentedRow(
            "Papel de parede", "Fundo animado ou imagem estática",
            arrayOf("Vídeo 1", "Vídeo 2", "Imagem", "Meu arquivo"),
            { prefs.wallpaper }, { prefs.wallpaper = it }
        )
        actionRow("Escolher do dispositivo", "Imagem ou vídeo do armazenamento / pendrive", null) { pickFile() }
        actionRow("Baixar wallpapers", "Abre o site MoeWalls (moewalls.com) para baixar fundos animados", null) {
            startActivity(Intent(this, WallpaperBrowserActivity::class.java))
        }
        actionRow("Wallpapers baixados", "Usar ou apagar os arquivos já baixados", "${downloadedFiles().size}") { showDownloaded() }
        toggleRow(
            "Modo economia", "Sem vídeo de fundo e monitor mais lento. Bom para TVs fracas.",
            { prefs.economy }, { prefs.economy = it }
        )
    }

    private fun pageDock() {
        sliderRow(
            "Tamanho da barra", "← diminui · → aumenta (ícones e altura da barra de tarefas)",
            60, 150, 10,
            { prefs.barSize }, { prefs.barSize = it },
            { "$it%" }
        )
        sliderRow(
            "Opacidade da barra", "← mais transparente · → mais sólida (0% = invisível)",
            0, 100, 5,
            { prefs.barOpacity }, { prefs.barOpacity = it },
            { if (it == 0) "Invisível" else "$it%" }
        )
        segmentedRow(
            "Posição", "Onde os ícones ficam na barra",
            arrayOf("Esquerda", "Meio", "Direita"),
            { prefs.dockAlign }, { prefs.dockAlign = it }
        )
        actionRow("Restaurar barra padrão", "Volta aos apps fixados originais", null) {
            prefs.resetFavorites()
            Toast.makeText(this, "Barra restaurada", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pageClock() {
        segmentedRow(
            "Fonte", "Anurati é a fonte original do relógio",
            arrayOf("Anurati", "Padrão"),
            { prefs.clockFont }, { prefs.clockFont = it }
        )
        segmentedRow(
            "Formato da hora", null,
            arrayOf("24 horas", "12 horas"),
            { if (prefs.clock24) 0 else 1 }, { prefs.clock24 = (it == 0) }
        )
        var cityView: TextView? = null
        cityView = actionRow("Cidade do clima", "Usada na previsão do tempo", prefs.city) {
            askCity { cityView?.text = prefs.city }
        }
    }

    private fun pageMonitor() {
        toggleRow(
            "Monitor de RAM / CPU", "Mostra o uso do sistema na tela inicial",
            { prefs.monitorOn }, { prefs.monitorOn = it }
        )
        segmentedRow(
            "Posição do monitor", null,
            arrayOf("Superior direito", "Inferior direito"),
            { if (prefs.monitorBottom) 1 else 0 }, { prefs.monitorBottom = (it == 1) }
        )
    }

    private fun pageMemory() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(18), dp(20), dp(18))
        box.background = rounded(14, Color.parseColor("#14FFFFFF"))

        val tv = TextView(this)
        tv.textSize = 17f
        tv.setTextColor(Color.parseColor("#7CF29A"))
        box.addView(tv)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.weightSum = 100f
        bar.background = rounded(5, Color.parseColor("#33FFFFFF"))
        val fill = View(this)
        fill.background = rounded(5, Color.parseColor("#7CF29A"))
        val rest = View(this)
        bar.addView(fill, LinearLayout.LayoutParams(0, MATCH, 0f))
        bar.addView(rest, LinearLayout.LayoutParams(0, MATCH, 100f))
        val lpBar = LinearLayout.LayoutParams(MATCH, dp(10))
        lpBar.topMargin = dp(12)
        box.addView(bar, lpBar)

        val lpBox = LinearLayout.LayoutParams(MATCH, WRAP)
        lpBox.bottomMargin = dp(8)
        content.addView(box, lpBox)

        ramText = tv
        ramFill = fill
        ramRest = rest
        updateRam()

        actionRow("Otimizar memória", "Encerra apps em segundo plano", null) {
            Toast.makeText(this, "Otimizando...", Toast.LENGTH_SHORT).show()
            Thread {
                val res = SysInfo.optimize(this)
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "Apps encerrados: ${res.first} · memória liberada: ${res.second} MB",
                        Toast.LENGTH_LONG
                    ).show()
                    updateRam()
                }
            }.start()
        }
    }

    private fun pageSystem() {
        actionRow("Configurações do Android", "Rede, vídeo, som e aplicativos", null) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Não foi possível abrir", Toast.LENGTH_SHORT).show()
            }
        }
        actionRow("Definir como launcher padrão", "Escolha Meu Launcher como tela inicial", null) {
            try {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Aperte o botão Home e escolha Meu Launcher", Toast.LENGTH_LONG).show()
            }
        }
        val row = baseRow("Versão", null)
        row.isFocusable = false
        row.isClickable = false
        row.background = rounded(14, Color.parseColor("#0DFFFFFF"))
        val v = TextView(this)
        v.text = "0.5"
        v.textSize = 15f
        v.setTextColor(textDim)
        row.addView(v)
    }

    private fun updateRam() {
        val t = ramText ?: return
        val m = SysInfo.memory(this)
        t.text = "RAM em uso: ${m.usedMb} / ${m.totalMb} MB (${m.percent}%)\nLivre: ${m.availMb} MB"
        val color = when {
            m.percent >= 85 -> Color.parseColor("#FF6B6B")
            m.percent >= 70 -> Color.parseColor("#FFD166")
            else -> Color.parseColor("#7CF29A")
        }
        t.setTextColor(color)
        val p = m.percent.toFloat().coerceIn(0f, 100f)
        val f = ramFill
        val r = ramRest
        if (f != null && r != null) {
            f.background = rounded(5, color)
            (f.layoutParams as LinearLayout.LayoutParams).weight = p
            (r.layoutParams as LinearLayout.LayoutParams).weight = 100f - p
            f.requestLayout()
            r.requestLayout()
        }
    }

    // ---------- Componentes ----------

    private fun rounded(radius: Int, color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dpf(radius)
        g.setColor(color)
        return g
    }

    private fun rowBg(): StateListDrawable {
        val focused = rounded(14, Color.parseColor("#2EFFFFFF"))
        focused.setStroke(dp(3), accent)
        val rest = rounded(14, Color.parseColor("#14FFFFFF"))
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), focused)
        sl.addState(intArrayOf(), rest)
        return sl
    }

    private fun sideItemBg(): StateListDrawable {
        val focused = rounded(12, accent)
        val selected = rounded(12, Color.parseColor("#26FFFFFF"))
        val rest = rounded(12, Color.TRANSPARENT)
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), focused)
        sl.addState(intArrayOf(android.R.attr.state_selected), selected)
        sl.addState(intArrayOf(), rest)
        return sl
    }

    /** Linha base: título + subtítulo à esquerda; o controle é adicionado à direita pelo chamador. */
    private fun baseRow(title: String, sub: String?): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(20), dp(14), dp(20), dp(14))
        row.background = rowBg()
        row.isFocusable = true
        row.isClickable = true

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.textSize = 17f
        t.setTextColor(Color.WHITE)
        col.addView(t)
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.textSize = 13f
            s.setTextColor(textFaint)
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.topMargin = dp(2)
            col.addView(s, lp)
        }
        val lpCol = LinearLayout.LayoutParams(0, WRAP, 1f)
        lpCol.rightMargin = dp(16)
        row.addView(col, lpCol)

        val lpRow = LinearLayout.LayoutParams(MATCH, WRAP)
        lpRow.bottomMargin = dp(8)
        content.addView(row, lpRow)
        return row
    }

    /** ← / → ajustam; nas pontas devolve false para o foco poder voltar ao menu lateral. */
    private fun setStepKeys(row: View, step: (Int) -> Boolean) {
        row.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> step(-1)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> step(1)
                    else -> false
                }
            } else false
        }
    }

    private fun segmentedRow(
        title: String,
        sub: String?,
        options: Array<String>,
        getter: () -> Int,
        onSet: (Int) -> Unit
    ) {
        val row = baseRow(title, sub)
        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.background = rounded(12, Color.parseColor("#22FFFFFF"))
        seg.setPadding(dp(3), dp(3), dp(3), dp(3))

        val chips = mutableListOf<TextView>()
        fun paint() {
            val sel = getter().coerceIn(0, options.size - 1)
            chips.forEachIndexed { i, c ->
                if (i == sel) {
                    c.background = rounded(10, accent)
                    c.setTextColor(Color.WHITE)
                } else {
                    c.background = null
                    c.setTextColor(textDim)
                }
            }
        }
        options.forEachIndexed { i, name ->
            val c = TextView(this)
            c.text = name
            c.textSize = 14f
            c.gravity = Gravity.CENTER
            c.setPadding(dp(14), dp(7), dp(14), dp(7))
            c.setOnClickListener {
                onSet(i)
                paint()
            }
            chips.add(c)
            seg.addView(c)
        }
        paint()
        row.addView(seg)

        row.setOnClickListener {
            onSet((getter() + 1) % options.size)
            paint()
        }
        setStepKeys(row) { d ->
            val cur = getter().coerceIn(0, options.size - 1)
            val n = (cur + d).coerceIn(0, options.size - 1)
            if (n == cur) {
                false
            } else {
                onSet(n)
                paint()
                true
            }
        }
    }

    private fun toggleRow(title: String, sub: String?, getter: () -> Boolean, onSet: (Boolean) -> Unit) {
        val row = baseRow(title, sub)
        val track = FrameLayout(this)
        val knob = View(this)
        val ov = GradientDrawable()
        ov.shape = GradientDrawable.OVAL
        ov.setColor(Color.WHITE)
        knob.background = ov
        track.addView(knob, FrameLayout.LayoutParams(dp(22), dp(22)))
        row.addView(track, LinearLayout.LayoutParams(dp(52), dp(30)))

        fun paint() {
            val on = getter()
            track.background = rounded(15, if (on) accent else Color.parseColor("#55FFFFFF"))
            val k = knob.layoutParams as FrameLayout.LayoutParams
            k.gravity = Gravity.CENTER_VERTICAL or (if (on) Gravity.END else Gravity.START)
            k.setMargins(dp(4), 0, dp(4), 0)
            knob.layoutParams = k
        }
        paint()

        row.setOnClickListener {
            onSet(!getter())
            paint()
        }
        setStepKeys(row) { d ->
            val on = getter()
            if (d > 0 && !on) {
                onSet(true); paint(); true
            } else if (d < 0 && on) {
                onSet(false); paint(); true
            } else {
                false
            }
        }
    }

    private fun sliderRow(
        title: String,
        sub: String?,
        min: Int,
        max: Int,
        stepSize: Int,
        getter: () -> Int,
        onSet: (Int) -> Unit,
        fmt: (Int) -> String
    ) {
        val row = baseRow(title, sub)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL

        val track = FrameLayout(this)
        track.background = rounded(4, Color.parseColor("#33FFFFFF"))
        val fill = View(this)
        fill.background = rounded(4, accent)
        track.addView(fill, FrameLayout.LayoutParams(0, MATCH))
        box.addView(track, LinearLayout.LayoutParams(dp(180), dp(8)))

        val value = TextView(this)
        value.textSize = 15f
        value.setTextColor(Color.WHITE)
        value.gravity = Gravity.END
        val lpVal = LinearLayout.LayoutParams(dp(84), WRAP)
        lpVal.leftMargin = dp(12)
        box.addView(value, lpVal)
        row.addView(box)

        fun paint() {
            val v = getter().coerceIn(min, max)
            val frac = (v - min).toFloat() / (max - min).toFloat()
            val lp = fill.layoutParams
            lp.width = (dp(180) * frac).toInt()
            fill.layoutParams = lp
            value.text = fmt(v)
        }
        paint()

        row.setOnClickListener {
            val cur = getter()
            onSet(if (cur >= max) min else (cur + stepSize).coerceAtMost(max))
            paint()
        }
        setStepKeys(row) { d ->
            val cur = getter().coerceIn(min, max)
            val n = (cur + d * stepSize).coerceIn(min, max)
            if (n == cur) {
                false
            } else {
                onSet(n)
                paint()
                true
            }
        }
    }

    /** Linha de ação. Mostra [valueText] à direita (ou uma seta ›). Devolve o texto da direita. */
    private fun actionRow(title: String, sub: String?, valueText: String?, onClick: () -> Unit): TextView {
        val row = baseRow(title, sub)
        val v = TextView(this)
        if (valueText != null) {
            v.text = valueText
            v.textSize = 16f
            v.setTextColor(accent)
        } else {
            v.text = "›"
            v.textSize = 26f
            v.setTextColor(textFaint)
        }
        row.addView(v)
        row.setOnClickListener { onClick() }
        return v
    }

    // ---------- Papel de parede próprio ----------

    private fun pickFile() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Esta TV não tem seletor de arquivos. Use \"Baixar wallpapers\" ou instale um gerenciador de arquivos.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Copiando arquivo…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val mime = contentResolver.getType(uri) ?: ""
                val ext = when {
                    mime.startsWith("video/") -> "mp4"
                    mime.contains("png") -> "png"
                    mime.contains("webp") -> "webp"
                    else -> "jpg"
                }
                val dir = WallpaperBrowserActivity.wallpaperDir(this)
                val out = java.io.File(dir, "dispositivo_" + System.currentTimeMillis() + "." + ext)
                contentResolver.openInputStream(uri)?.use { inp -> out.outputStream().use { inp.copyTo(it) } }
                runOnUiThread {
                    prefs.customWallpaper = out.absolutePath
                    prefs.wallpaper = 3
                    Toast.makeText(this, "Papel de parede aplicado", Toast.LENGTH_SHORT).show()
                    current = -1
                    showPage(0)
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Não foi possível abrir o arquivo", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun downloadedFiles(): List<java.io.File> =
        (WallpaperBrowserActivity.wallpaperDir(this).listFiles() ?: emptyArray())
            .filter { it.isFile }.sortedByDescending { it.lastModified() }

    private fun showDownloaded() {
        val files = downloadedFiles()
        if (files.isEmpty()) {
            Toast.makeText(this, "Nenhum wallpaper baixado ainda", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Wallpapers baixados")
            .setItems(files.map { it.name }.toTypedArray()) { _, which ->
                val f = files[which]
                AlertDialog.Builder(this)
                    .setTitle(f.name)
                    .setPositiveButton("Usar") { _, _ ->
                        prefs.customWallpaper = f.absolutePath
                        prefs.wallpaper = 3
                        current = -1
                        showPage(0)
                    }
                    .setNegativeButton("Apagar") { _, _ ->
                        f.delete()
                        current = -1
                        showPage(0)
                    }
                    .setNeutralButton("Cancelar", null)
                    .show()
            }
            .show()
    }

    private fun askCity(onDone: () -> Unit) {
        val et = EditText(this)
        et.setText(prefs.city)
        et.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Cidade do clima")
            .setView(et)
            .setPositiveButton("Salvar") { _, _ ->
                val c = et.text.toString().trim()
                if (c.isNotEmpty()) {
                    prefs.city = c
                    prefs.weatherTime = 0L
                }
                onDone()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    companion object {
        private const val REQ_PICK = 4711
    }
}
