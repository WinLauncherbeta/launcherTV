package com.meulauncher.tv

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.dpf(v: Int): Float = v * resources.displayMetrics.density

/** Fundo que ganha borda branca quando o item está em foco (controle remoto). */
fun Context.focusBg(radius: Int): StateListDrawable {
    val focused = GradientDrawable()
    focused.cornerRadius = dpf(radius)
    focused.setColor(Color.parseColor("#33FFFFFF"))
    focused.setStroke(dp(3), Color.WHITE)
    val rest = GradientDrawable()
    rest.cornerRadius = dpf(radius)
    rest.setColor(Color.TRANSPARENT)
    val sl = StateListDrawable()
    sl.addState(intArrayOf(android.R.attr.state_focused), focused)
    sl.addState(intArrayOf(), rest)
    return sl
}

fun View.scaleOnFocus(scale: Float) {
    onFocusChangeListener = View.OnFocusChangeListener { v, has ->
        val s = if (has) scale else 1f
        v.animate().scaleX(s).scaleY(s).setDuration(120).start()
    }
}

/** Fundo de foco suave (sem borda branca): só um brilho translúcido por trás do ícone. */
fun Context.softFocusBg(radius: Int): StateListDrawable {
    val focused = GradientDrawable()
    focused.cornerRadius = dpf(radius)
    focused.setColor(Color.parseColor("#26FFFFFF"))
    val rest = GradientDrawable()
    rest.cornerRadius = dpf(radius)
    rest.setColor(Color.TRANSPARENT)
    val sl = StateListDrawable()
    sl.addState(intArrayOf(android.R.attr.state_focused), focused)
    sl.addState(intArrayOf(android.R.attr.state_hovered), focused)
    sl.addState(intArrayOf(), rest)
    return sl
}

private fun popAnimate(v: View, on: Boolean, scale: Float, liftDp: Int) {
    val lift = if (on) -v.context.dpf(liftDp) else 0f
    val s = if (on) scale else 1f
    v.animate().cancel()
    v.animate()
        .translationY(lift).scaleX(s).scaleY(s)
        .setDuration(if (on) 260L else 150L)
        .setInterpolator(if (on) OvershootInterpolator(2.6f) else DecelerateInterpolator())
        .start()
}

/** Efeito "pop-up": ao focar (controle) ou passar o mouse, o item dá uma saltadinha para cima. */
fun View.popOnFocus(scale: Float = 1.12f, liftDp: Int = 9) {
    onFocusChangeListener = View.OnFocusChangeListener { v, has -> popAnimate(v, has, scale, liftDp) }
    setOnHoverListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_HOVER_ENTER -> popAnimate(v, true, scale, liftDp)
            MotionEvent.ACTION_HOVER_EXIT -> popAnimate(v, v.isFocused, scale, liftDp)
        }
        false
    }
}
