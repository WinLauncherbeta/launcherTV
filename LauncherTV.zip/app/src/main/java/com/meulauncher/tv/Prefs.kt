package com.meulauncher.tv

import android.content.Context
import android.content.SharedPreferences

class Prefs(ctx: Context) {
    private val app = ctx.applicationContext
    private val sp: SharedPreferences = app.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    /** 0 = vídeo 1, 1 = vídeo 2, 2 = imagem estática, 3 = arquivo próprio (do dispositivo/baixado) */
    var wallpaper: Int
        get() = sp.getInt("wallpaper", 0)
        set(v) { sp.edit().putInt("wallpaper", v).apply() }

    /** Caminho do arquivo (imagem ou vídeo) usado quando wallpaper == 3 */
    var customWallpaper: String
        get() = sp.getString("customWallpaper", "") ?: ""
        set(v) { sp.edit().putString("customWallpaper", v).apply() }

    /** Tamanho da barra de tarefas (ícones + altura) em % — 60 a 150, padrão 100 */
    var barSize: Int
        get() = sp.getInt("barSize", 100)
        set(v) { sp.edit().putInt("barSize", v.coerceIn(60, 150)).apply() }

    /** Posição do dock: 0 = esquerda, 1 = meio, 2 = direita */
    var dockAlign: Int
        get() = sp.getInt("dockAlign", 1)
        set(v) { sp.edit().putInt("dockAlign", v).apply() }

    /** Opacidade da barra de tarefas em % (0 = transparente, 100 = sólida) */
    var barOpacity: Int
        get() = sp.getInt("barOpacity", 55)
        set(v) { sp.edit().putInt("barOpacity", v.coerceIn(0, 100)).apply() }

    /** Fonte do relógio: 0 = Anurati (original), 1 = fonte padrão do sistema */
    var clockFont: Int
        get() = sp.getInt("clockFont", 0)
        set(v) { sp.edit().putInt("clockFont", v).apply() }

    var clock24: Boolean
        get() = sp.getBoolean("clock24", true)
        set(v) { sp.edit().putBoolean("clock24", v).apply() }

    var city: String
        get() = sp.getString("city", "São Paulo") ?: "São Paulo"
        set(v) { sp.edit().putString("city", v).apply() }

    var monitorOn: Boolean
        get() = sp.getBoolean("monitorOn", true)
        set(v) { sp.edit().putBoolean("monitorOn", v).apply() }

    var monitorBottom: Boolean
        get() = sp.getBoolean("monitorBottom", false)
        set(v) { sp.edit().putBoolean("monitorBottom", v).apply() }

    var economy: Boolean
        get() = sp.getBoolean("economy", false)
        set(v) { sp.edit().putBoolean("economy", v).apply() }

    var weatherText: String
        get() = sp.getString("weatherText", "") ?: ""
        set(v) { sp.edit().putString("weatherText", v).apply() }

    var weatherTime: Long
        get() = sp.getLong("weatherTime", 0L)
        set(v) { sp.edit().putLong("weatherTime", v).apply() }

    var weatherCity: String
        get() = sp.getString("weatherCity", "") ?: ""
        set(v) { sp.edit().putString("weatherCity", v).apply() }

    /** Apps fixados no dock. Se o usuário nunca mexeu, usa a lista padrão (só os instalados). */
    fun favorites(): MutableList<String> {
        val raw = sp.getString("fav", null)
        if (raw == null) {
            val pm = app.packageManager
            return Apps.defaultFavorites.filter { Apps.launchIntent(pm, it) != null }.toMutableList()
        }
        return if (raw.isEmpty()) mutableListOf() else raw.split("|").toMutableList()
    }

    fun setFavorites(list: List<String>) {
        sp.edit().putString("fav", list.joinToString("|")).apply()
    }

    fun resetFavorites() {
        sp.edit().remove("fav").apply()
    }
}
